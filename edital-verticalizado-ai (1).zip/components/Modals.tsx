import React, { useState, useEffect, useMemo } from 'react';
import { 
  X, Trash2, Brain, BookOpen, HelpCircle, Lightbulb, 
  Loader, BarChart2, AlertCircle, Clock, Eye 
} from 'lucide-react';
import { Edital, Topic, AnalysisData } from '../types';
import { generateTutorResponse } from '../gemini';

export const ConfirmationModal: React.FC<{
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
  title: string;
  message: string;
}> = ({ isOpen, onClose, onConfirm, title, message }) => {
  if (!isOpen) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4 animate-fadeIn">
      <div className="bg-white rounded-xl shadow-2xl max-w-md w-full overflow-hidden border border-slate-200">
        <div className="p-6">
          <div className="flex items-center gap-3 mb-4 text-red-600">
            <div className="bg-red-100 p-2 rounded-full"><Trash2 size={24} /></div>
            <h3 className="text-xl font-bold text-slate-800">{title}</h3>
          </div>
          <p className="text-slate-600 mb-8 leading-relaxed">{message}</p>
          <div className="flex justify-end gap-3">
            <button onClick={onClose} className="px-5 py-2.5 text-slate-600 font-medium hover:bg-slate-100 rounded-lg">Cancelar</button>
            <button onClick={onConfirm} className="px-5 py-2.5 bg-red-600 text-white font-bold rounded-lg hover:bg-red-700 shadow-lg shadow-red-200">Sim, Excluir</button>
          </div>
        </div>
      </div>
    </div>
  );
};

export const InputModal: React.FC<{
  isOpen: boolean;
  onClose: () => void;
  onConfirm: (val: string) => void;
  title: string;
  placeholder: string;
  initialValue?: string;
}> = ({ isOpen, onClose, onConfirm, title, placeholder, initialValue = '' }) => {
  const [value, setValue] = useState(initialValue);
  useEffect(() => { if (isOpen) setValue(initialValue); }, [isOpen, initialValue]);

  if (!isOpen) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4 animate-fadeIn">
      <div className="bg-white rounded-xl shadow-2xl max-w-md w-full p-6 border border-slate-200">
        <h3 className="text-lg font-bold text-slate-800 mb-4">{title}</h3>
        <input 
          autoFocus 
          className="w-full p-3 border border-slate-300 rounded-lg mb-4 focus:ring-2 focus:ring-indigo-500 outline-none" 
          placeholder={placeholder} 
          value={value} 
          onChange={e => setValue(e.target.value)} 
          onKeyDown={e => e.key === 'Enter' && value.trim() && onConfirm(value)} 
        />
        <div className="flex justify-end gap-3">
          <button onClick={onClose} className="px-4 py-2 text-slate-500 hover:bg-slate-100 rounded-lg">Cancelar</button>
          <button onClick={() => value.trim() && onConfirm(value)} className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 font-bold shadow-sm">Confirmar</button>
        </div>
      </div>
    </div>
  );
};

export const AITutorModal: React.FC<{
  isOpen: boolean;
  onClose: () => void;
  topicText: string;
  subjectTitle: string;
}> = ({ isOpen, onClose, topicText, subjectTitle }) => {
  const [loading, setLoading] = useState(false);
  const [response, setResponse] = useState<string | null>(null);
  const [mode, setMode] = useState<'explain' | 'quiz' | 'tips' | null>(null);

  if (!isOpen) return null;

  const handleAction = async (selectedMode: 'explain' | 'quiz' | 'tips') => {
    setMode(selectedMode);
    setLoading(true);
    setResponse(null);
    const text = await generateTutorResponse(topicText, subjectTitle, selectedMode);
    setResponse(text);
    setLoading(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 animate-fadeIn">
      <div className="bg-white rounded-xl shadow-2xl max-w-2xl w-full flex flex-col max-h-[90vh] overflow-hidden border border-indigo-100">
        <div className="p-4 border-b border-indigo-50 bg-indigo-50/50 flex justify-between items-center">
          <div className="flex items-center gap-2 text-indigo-700">
            <Brain size={24} className="fill-indigo-200" />
            <h3 className="font-bold text-lg">Tutor Inteligente</h3>
          </div>
          <button onClick={onClose} className="p-1 hover:bg-slate-200 rounded-full text-slate-500"><X size={20} /></button>
        </div>
        <div className="p-6 overflow-y-auto flex-1">
          <div className="mb-6">
            <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-wide mb-1">Tópico Selecionado</h4>
            <p className="text-slate-800 font-medium text-lg leading-snug">{topicText}</p>
          </div>
          
          {!response && !loading && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              <ActionButton 
                onClick={() => handleAction('explain')} 
                icon={<BookOpen size={24} className="text-blue-600"/>} 
                bg="bg-blue-100" 
                label="Explicar Conceito" 
              />
              <ActionButton 
                onClick={() => handleAction('quiz')} 
                icon={<HelpCircle size={24} className="text-purple-600"/>} 
                bg="bg-purple-100" 
                label="Gerar Questão" 
              />
              <ActionButton 
                onClick={() => handleAction('tips')} 
                icon={<Lightbulb size={24} className="text-amber-600"/>} 
                bg="bg-amber-100" 
                label="Dicas de Estudo" 
              />
            </div>
          )}

          {loading && (
            <div className="flex flex-col items-center justify-center py-10 space-y-4">
              <Loader className="animate-spin text-indigo-600" size={40} />
              <p className="text-slate-500 animate-pulse font-medium">Consultando a base de conhecimento...</p>
            </div>
          )}

          {response && (
            <div className="animate-fadeIn">
              <div className="flex justify-between items-center mb-4">
                <span className="text-xs font-bold px-2 py-1 bg-indigo-100 text-indigo-700 rounded uppercase">
                  {mode === 'explain' ? 'Resumo' : mode === 'quiz' ? 'Questão Prática' : 'Dicas'}
                </span>
                <button onClick={() => setResponse(null)} className="text-xs text-slate-400 hover:text-indigo-600 underline">Fazer outra pergunta</button>
              </div>
              <div className="prose prose-sm prose-slate max-w-none bg-slate-50 p-4 rounded-lg border border-slate-100 text-slate-700 whitespace-pre-wrap leading-relaxed">
                {response}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

const ActionButton: React.FC<{ onClick: () => void, icon: React.ReactNode, bg: string, label: string }> = ({ onClick, icon, bg, label }) => (
  <button onClick={onClick} className="flex flex-col items-center justify-center p-4 border border-slate-200 rounded-xl hover:bg-indigo-50 hover:border-indigo-200 transition-all group">
    <div className={`${bg} p-3 rounded-full mb-2 group-hover:scale-110 transition-transform`}>{icon}</div>
    <span className="font-bold text-slate-700">{label}</span>
  </button>
);

export const AnalysisModal: React.FC<{
  isOpen: boolean;
  onClose: () => void;
  data: Edital;
}> = ({ isOpen, onClose, data }) => {
  const [activeTab, setActiveTab] = useState<'weakness' | 'frequency'>('weakness');

  const analysis = useMemo(() => {
    const allTopics: AnalysisData[] = [];
    if (!data || !data.categories) return allTopics;

    const traverse = (topics: Topic[], category: string, subject: string) => {
      topics.forEach(t => {
        if (t.children && t.children.length > 0) traverse(t.children, category, subject);
        
        let totalHits = 0;
        let totalQuestions = 0;
        const reviewsCount = t.reviews ? t.reviews.length : 0;
        
        if (t.reviews && t.reviews.length > 0) {
          t.reviews.forEach(r => {
            totalHits += (r.hits || 0);
            totalQuestions += (r.total || 0);
          });
        }
        const percentage = totalQuestions > 0 ? (totalHits / totalQuestions) * 100 : null;
        allTopics.push({ id: t.id, text: t.text, category, subject, reviews: reviewsCount, percentage: percentage, seen: t.seen });
      });
    };
    
    data.categories.forEach(cat => {
        cat.subjects.forEach(sub => {
            traverse(sub.topics || [], cat.title, sub.title);
        });
    });
    return allTopics;
  }, [data]);

  if (!isOpen) return null;

  const worstTopics = analysis.filter(t => t.percentage !== null).sort((a, b) => (a.percentage || 0) - (b.percentage || 0)).slice(0, 10);
  const leastStudied = analysis.filter(t => t.seen).sort((a, b) => a.reviews - b.reviews).slice(0, 10);
  const notStudied = analysis.filter(t => !t.seen).length;

  const getPerformanceColor = (percentage: number) => {
    if (percentage >= 80) return 'text-green-600 bg-green-50 border-green-200';
    if (percentage >= 60) return 'text-yellow-600 bg-yellow-50 border-yellow-200';
    return 'text-red-600 bg-red-50 border-red-200';
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 animate-fadeIn">
      <div className="bg-white rounded-xl shadow-2xl max-w-4xl w-full flex flex-col max-h-[90vh] overflow-hidden border border-slate-200">
        <div className="p-4 border-b border-slate-100 flex justify-between items-center bg-slate-50">
          <h3 className="font-bold text-xl text-slate-800 flex items-center gap-2">
            <BarChart2 className="text-indigo-600"/> Análise de Desempenho
          </h3>
          <button onClick={onClose} className="p-1 hover:bg-slate-200 rounded-full text-slate-500"><X size={20}/></button>
        </div>
        
        <div className="flex border-b border-slate-200">
          <button onClick={() => setActiveTab('weakness')} className={`flex-1 py-3 text-sm font-bold flex items-center justify-center gap-2 border-b-2 transition-colors ${activeTab === 'weakness' ? 'border-red-500 text-red-600 bg-red-50' : 'border-transparent text-slate-500 hover:bg-slate-50'}`}>
            <AlertCircle size={16}/> Pontos Fracos (% Acertos)
          </button>
          <button onClick={() => setActiveTab('frequency')} className={`flex-1 py-3 text-sm font-bold flex items-center justify-center gap-2 border-b-2 transition-colors ${activeTab === 'frequency' ? 'border-amber-500 text-amber-600 bg-amber-50' : 'border-transparent text-slate-500 hover:bg-slate-50'}`}>
            <Clock size={16}/> Menos Revisados
          </button>
        </div>

        <div className="p-6 overflow-y-auto bg-slate-50/50 flex-1">
          {activeTab === 'weakness' && (
            <div className="space-y-4">
              {worstTopics.length === 0 ? <p className="text-slate-400 italic text-center py-4">Sem dados de questões suficientes para análise.</p> : 
                worstTopics.map((item, idx) => (
                  <div key={idx} className="flex items-center justify-between mb-2 border-b border-slate-200 pb-2 last:border-0">
                    <div className="flex-1 pr-4">
                      <div className="text-xs text-slate-400 font-semibold">{item.subject}</div>
                      <div className="text-sm font-medium">{item.text}</div>
                    </div>
                    <div className={`px-2 py-1 rounded text-xs font-bold border ${getPerformanceColor(item.percentage || 0)}`}>
                      {Math.round(item.percentage || 0)}%
                    </div>
                  </div>
                ))
              }
            </div>
          )}
          {activeTab === 'frequency' && (
            <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                   <div className="bg-white p-4 rounded-lg shadow-sm border border-slate-200 flex items-center gap-3">
                     <div className="bg-slate-100 p-3 rounded-full"><Eye size={24} className="text-slate-400"/></div>
                     <div>
                       <div className="text-2xl font-bold text-slate-800">{notStudied}</div>
                       <div className="text-xs text-slate-500 font-bold uppercase">Tópicos Nunca Vistos</div>
                     </div>
                   </div>
                </div>
                <h4 className="text-xs font-bold text-slate-400 uppercase mb-2">Revisados com menor frequência</h4>
                {leastStudied.length === 0 ? <p className="text-slate-400 italic text-center py-4">Sem dados para este período.</p> : 
                  leastStudied.map((item, idx) => (
                    <div key={idx} className="flex items-center justify-between mb-2 border-b border-slate-200 pb-2 last:border-0">
                      <div className="flex-1 pr-4">
                        <div className="text-xs text-slate-400 font-semibold">{item.subject}</div>
                        <div className="text-sm font-medium">{item.text}</div>
                      </div>
                      <div className="text-xs font-bold bg-amber-100 text-amber-700 px-2 py-1 rounded">{item.reviews} revs</div>
                    </div>
                  ))
                }
            </div>
          )}
        </div>
      </div>
    </div>
  );
};