import React, { useState, useMemo, useRef } from 'react';
import { 
  Check, ChevronDown, ChevronUp, Clock, Edit2, 
  Folder, FolderOpen, GripVertical, Plus, Sparkles, 
  StickyNote, Trash2, Bell, CalendarClock, X 
} from 'lucide-react';
import { Topic, Subject, Review } from '../types';

const formatDate = (isoString?: string) => {
  if (!isoString) return '-';
  try {
    return new Date(isoString).toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' });
  } catch { return '-'; }
};

const isOverdue = (dateString?: string) => {
  if (!dateString) return false;
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const reviewDate = new Date(dateString);
  reviewDate.setHours(0, 0, 0, 0);
  return today >= reviewDate;
};

const getPerformanceColor = (percentage: number) => {
  if (percentage >= 80) return 'text-green-600 bg-green-50 border-green-200';
  if (percentage >= 60) return 'text-yellow-600 bg-yellow-50 border-yellow-200';
  return 'text-red-600 bg-red-50 border-red-200';
};

interface ReviewFormProps {
  onSave: (stats: { total: number; hits: number; notes: string; nextReview: string }) => void;
  onCancel: () => void;
}

const ReviewForm: React.FC<ReviewFormProps> = ({ onSave, onCancel }) => {
  const [total, setTotal] = useState('');
  const [hits, setHits] = useState('');
  const [notes, setNotes] = useState('');
  const [error, setError] = useState('');
  const [reviewType, setReviewType] = useState('1'); 
  const [customDate, setCustomDate] = useState('');

  const handleSubmit = () => {
    setError('');
    let t = 0, h = 0;
    if (total !== '' || hits !== '') {
        t = parseInt(total);
        h = parseInt(hits);
        if (isNaN(t) || isNaN(h)) return setError("Use números válidos.");
        if (h > t) return setError("Acertos > Total?");
    } else if (!notes.trim()) {
        return setError("Preencha observações ou questões.");
    }

    let nextDate = new Date();
    if (reviewType === 'custom' && customDate) {
        nextDate = new Date(customDate);
    } else {
        nextDate.setDate(nextDate.getDate() + parseInt(reviewType));
    }
    nextDate.setHours(23, 59, 59, 999);

    onSave({ total: t, hits: h, notes, nextReview: nextDate.toISOString() });
  };

  return (
    <div className="bg-slate-50 p-4 rounded-lg border border-indigo-100 mt-2 animate-fadeIn shadow-inner">
      <div className="mb-4">
          <label className="block text-[10px] text-slate-500 uppercase font-bold mb-1 flex items-center gap-1"><StickyNote size={10}/> Notas</label>
          <textarea 
            value={notes} 
            onChange={e => setNotes(e.target.value)} 
            className="w-full p-2 text-sm border rounded focus:ring-2 focus:ring-indigo-500 min-h-[60px]" 
            placeholder="O que foi estudado?"
          />
      </div>
      <div className="flex gap-3 mb-4">
        <div className="flex-1"><label className="block text-[10px] text-slate-500 uppercase font-bold mb-1">Questões</label><input type="number" min="0" value={total} onChange={e => setTotal(e.target.value)} className="w-full p-2 text-sm border rounded" placeholder="Total" /></div>
        <div className="flex-1"><label className="block text-[10px] text-slate-500 uppercase font-bold mb-1">Acertos</label><input type="number" min="0" value={hits} onChange={e => setHits(e.target.value)} className="w-full p-2 text-sm border rounded" placeholder="Acertos" /></div>
      </div>
      <div className="mb-4">
         <label className="block text-[10px] text-slate-500 uppercase font-bold mb-2 flex items-center gap-1"><CalendarClock size={12}/> Próxima Revisão</label>
         <div className="grid grid-cols-3 gap-2 mb-2">
            {['1', '3', '7', '15', '30'].map(day => (
                <button key={day} onClick={() => setReviewType(day)} className={`text-xs py-1.5 rounded border transition-all ${reviewType === day ? 'bg-indigo-600 text-white border-indigo-600' : 'bg-white text-slate-600 hover:bg-slate-100'}`}>{day} dias</button>
            ))}
            <button onClick={() => setReviewType('custom')} className={`text-xs py-1.5 rounded border ${reviewType === 'custom' ? 'bg-indigo-600 text-white' : 'bg-white'}`}>Data</button>
         </div>
         {reviewType === 'custom' && (<input type="date" value={customDate} onChange={e => setCustomDate(e.target.value)} className="w-full p-2 text-xs border rounded" />)}
      </div>
      {error && <div className="text-xs text-red-500 font-bold mb-3">{error}</div>}
      <div className="flex justify-end gap-2"><button onClick={onCancel} className="px-3 py-1.5 text-xs text-slate-500 hover:bg-slate-200 rounded">Cancelar</button><button onClick={handleSubmit} className="px-3 py-1.5 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded shadow-sm">Salvar</button></div>
    </div>
  );
};

interface TopicItemProps {
  topic: Topic;
  parentId: string | null;
  subjectId: string;
  catId: string;
  index: number;
  depth?: number;
  onToggleSeen: (catId: string, subId: string, topicId: string) => void;
  onAddReview: (catId: string, subId: string, topicId: string, stats: any, parentId: string | null) => void;
  onDeleteReview: (catId: string, subId: string, topicId: string, idx: number) => void;
  onDeleteTopic: (catId: string, subId: string, topicId: string) => void;
  onAddSubtopic: (parentId: string) => void;
  onOpenAI: (text: string) => void;
  onReorder: (catId: string, subId: string, parentId: string | null, from: number, to: number) => void;
  onEdit: (id: string, text: string) => void;
}

export const TopicItem: React.FC<TopicItemProps> = (props) => {
  const { topic, onToggleSeen, onAddReview, onDeleteReview, onDeleteTopic, onAddSubtopic, onOpenAI, onReorder, onEdit, index } = props;
  const [isOpen, setIsOpen] = useState(false);
  const [showHistory, setShowHistory] = useState(false);
  const [isAddingReview, setIsAddingReview] = useState(false);
  const dragItem = useRef<number | null>(null);
  const dragOverItem = useRef<number | null>(null);

  const hasChildren = topic.children && topic.children.length > 0;
  const isTopicOverdue = useMemo(() => isOverdue(topic.nextReview), [topic.nextReview]);

  const handleDragStart = (e: React.DragEvent, position: number) => { dragItem.current = position; e.dataTransfer.effectAllowed = "move"; };
  const handleDragEnter = (e: React.DragEvent, position: number) => { dragOverItem.current = position; };
  const handleDrop = (e: React.DragEvent) => { e.preventDefault(); if (dragItem.current !== null && dragOverItem.current !== null && dragItem.current !== dragOverItem.current) { props.onReorder(props.catId, props.subjectId, props.parentId, dragItem.current, dragOverItem.current); } dragItem.current = null; dragOverItem.current = null; };

  if (hasChildren) {
    let total = 0, seen = 0;
    const count = (list?: Topic[]) => list?.forEach(t => { if(t.children?.length) count(t.children); else { total++; if(t.seen) seen++; } });
    count(topic.children);
    const pct = total === 0 ? 0 : Math.round((seen/total)*100);

    return (
      <div className={`mb-3 rounded-lg border transition-all duration-300 ${isOpen ? 'bg-slate-50 border-slate-300' : 'bg-white border-slate-200'}`} draggable onDragStart={e => handleDragStart(e, index)} onDragEnter={e => handleDragEnter(e, index)} onDragEnd={handleDrop} onDragOver={e => e.preventDefault()}>
        <div className="flex items-center p-3 cursor-pointer hover:bg-slate-50 rounded-lg select-none" onClick={() => setIsOpen(!isOpen)}>
          <GripVertical size={16} className="text-slate-300 mr-2 cursor-move" />
          <div className="mr-3 text-indigo-500">{isOpen ? <FolderOpen size={20} /> : <Folder size={20} />}</div>
          <div className="flex-1 pr-2">
            <div className="flex justify-between items-center mb-1"><span className="font-bold text-slate-800 text-sm">{topic.text}</span></div>
            <div className="flex items-center gap-2">
                <div className="flex-1 bg-slate-200 rounded-full h-1.5 overflow-hidden"><div className="h-full bg-indigo-500" style={{ width: `${pct}%` }}></div></div>
                <span className="text-[10px] font-bold text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded-full">{seen}/{total}</span>
            </div>
          </div>
          <div className="flex items-center gap-1">
             <button onClick={(e) => {e.stopPropagation(); onEdit(topic.id, topic.text)}} className="p-1.5 text-slate-400 hover:text-blue-500"><Edit2 size={16}/></button>
             <button onClick={(e) => { e.stopPropagation(); onAddSubtopic(topic.id); }} className="p-1.5 text-slate-400 hover:text-indigo-600"><Plus size={18} /></button>
             <button onClick={(e) => { e.stopPropagation(); onDeleteTopic(props.catId, props.subjectId, topic.id); }} className="p-1.5 text-slate-400 hover:text-red-600"><Trash2 size={18} /></button>
             <div className="ml-2 text-slate-400">{isOpen ? <ChevronUp size={20} /> : <ChevronDown size={20} />}</div>
          </div>
        </div>
        {isOpen && <div className="p-2 pl-6 border-t border-slate-200 space-y-2 bg-slate-50/50">{topic.children!.map((child, idx) => <TopicItem key={child.id} {...props} index={idx} topic={child} parentId={topic.id} depth={(props.depth || 0) + 1} />)}</div>}
      </div>
    );
  }

  const lastReview = topic.reviews?.length ? topic.reviews[topic.reviews.length - 1] : null;
  const lastReviewPercent = (lastReview && lastReview.total > 0) ? Math.round((lastReview.hits / lastReview.total) * 100) : null;
  
  return (
    <div className={`flex flex-col rounded border transition-all duration-200 ${isTopicOverdue ? 'bg-red-50 border-red-200' : topic.seen ? 'bg-green-50 border-green-200' : 'bg-white border-slate-200'}`} draggable onDragStart={e => handleDragStart(e, index)} onDragEnter={e => handleDragEnter(e, index)} onDragEnd={handleDrop} onDragOver={e => e.preventDefault()}>
      <div className="flex items-start p-3 gap-3">
        <GripVertical size={14} className="text-slate-300 mt-1 cursor-move" />
        <button onClick={() => onToggleSeen(props.catId, props.subjectId, topic.id)} className={`mt-0.5 h-5 w-5 rounded border flex items-center justify-center transition-colors shrink-0 ${topic.seen ? 'bg-green-500 border-green-600 text-white' : 'bg-white border-slate-300 text-transparent hover:border-green-400'}`}><Check size={12} strokeWidth={4} /></button>
        <div className="flex-1">
          <span className={`text-sm leading-snug ${topic.seen ? 'text-slate-700 font-medium' : 'text-slate-600'}`}>{topic.text}</span>
          {isTopicOverdue && (<div className="mt-2 inline-flex items-center gap-1 text-[10px] font-bold text-white bg-red-500 px-2 py-0.5 rounded-full animate-pulse shadow-sm"><Bell size={10} fill="currentColor"/> REVISAR HOJE</div>)}
          {!isTopicOverdue && lastReview && (
            <div className="mt-2 flex items-center gap-2 flex-wrap">
              <span className="flex items-center gap-1 text-[10px] text-blue-600 font-semibold bg-blue-100 px-2 py-0.5 rounded-full"><Clock size={10} /> {formatDate(lastReview.date)}</span>
              {lastReviewPercent !== null && (<span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${getPerformanceColor(lastReviewPercent)}`}>{lastReviewPercent}%</span>)}
              {lastReview.notes && (<span className="flex items-center gap-1 text-[10px] text-slate-600 font-medium bg-slate-100 px-2 py-0.5 rounded-full" title={lastReview.notes}><StickyNote size={10} /> Nota</span>)}
            </div>
          )}
        </div>
        <div className="flex items-center gap-1">
          <button onClick={() => onOpenAI(topic.text)} className="p-1.5 text-indigo-400 hover:text-white hover:bg-gradient-to-r from-indigo-500 to-purple-500 rounded-full" title="Tutor IA"><Sparkles size={16} /></button>
          <button onClick={() => setIsAddingReview(!isAddingReview)} disabled={!topic.seen} className={`p-1.5 rounded flex items-center gap-1 text-[10px] font-bold uppercase tracking-wide transition-colors ${topic.seen ? 'bg-indigo-100 text-indigo-700 hover:bg-indigo-200' : 'bg-slate-100 text-slate-300 cursor-not-allowed'}`}><Plus size={12} /> <span className="hidden sm:inline">Revisar</span></button>
          <button onClick={() => onAddSubtopic(topic.id)} className="p-1.5 text-slate-400 hover:text-indigo-600"><Plus size={16} /></button>
          <button onClick={() => onEdit(topic.id, topic.text)} className="p-1.5 text-slate-400 hover:text-blue-500"><Edit2 size={16}/></button>
          <button onClick={() => onDeleteTopic(props.catId, props.subjectId, topic.id)} className="p-1.5 text-slate-300 hover:text-red-500"><Trash2 size={16} /></button>
          <button onClick={() => setShowHistory(!showHistory)} disabled={!topic.reviews?.length} className={`p-1.5 rounded-full ${topic.reviews?.length ? 'text-slate-500 hover:bg-slate-200' : 'text-slate-200'}`}><Clock size={16} /></button>
        </div>
      </div>
      {isAddingReview && <div className="px-3 pb-3"><ReviewForm onSave={(stats) => { onAddReview(props.catId, props.subjectId, topic.id, stats, props.parentId); setIsAddingReview(false); setShowHistory(true); }} onCancel={() => setIsAddingReview(false)} /></div>}
      {showHistory && topic.reviews && topic.reviews.length > 0 && (
        <div className="bg-slate-100 p-3 border-t border-slate-200 text-xs animate-slideDown">
          <table className="w-full text-left bg-white rounded overflow-hidden shadow-sm border border-slate-200">
            <thead className="bg-slate-50 text-slate-500"><tr><th className="p-2">Data</th><th className="p-2 text-center">Desempenho</th><th className="p-2">Obs</th><th className="p-2 text-right">#</th></tr></thead>
            <tbody>
              {topic.reviews.map((rev, idx) => {
                const percent = rev.total > 0 ? Math.round((rev.hits / rev.total) * 100) : null;
                return (
                  <tr key={idx} className="border-b border-slate-100 last:border-0">
                    <td className="p-2 font-mono text-slate-700">{formatDate(rev.date)}</td>
                    <td className="p-2 text-center">{percent !== null ? <span className={`px-2 py-0.5 rounded font-bold border ${getPerformanceColor(percent)}`}>{percent}%</span> : <span className="text-slate-400">-</span>}</td>
                    <td className="p-2 text-center">{rev.notes && <div className="group relative"><StickyNote size={14} className="text-slate-400 mx-auto cursor-help" /><div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-1 hidden group-hover:block bg-slate-800 text-white p-2 rounded text-xs w-48 z-10">{rev.notes}</div></div>}</td>
                    <td className="p-2 text-right"><button onClick={() => onDeleteReview(props.catId, props.subjectId, topic.id, idx)} className="text-slate-300 hover:text-red-500"><X size={12} /></button></td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export const SubjectCard: React.FC<{
  subject: Subject;
  catId: string;
  onDeleteSubject: () => void;
  onAddTopic: () => void;
  onReorder: (cId: string, sId: string, pId: string | null, from: number, to: number) => void;
  onEditTopic: (id: string, text: string, isSubj?: boolean) => void;
  onToggleSeen: (catId: string, subId: string, topicId: string) => void;
  onAddReview: (catId: string, subId: string, topicId: string, stats: any, parentId: string | null) => void;
  onDeleteReview: (catId: string, subId: string, topicId: string, idx: number) => void;
  onDeleteTopic: (catId: string, subId: string, topicId: string) => void;
  onAddSubtopic: (parentId: string) => void;
  onOpenAI: (text: string) => void;
}> = ({ subject, catId, onDeleteSubject, onAddTopic, onReorder, onEditTopic, ...props }) => {
  const [isOpen, setIsOpen] = useState(false);
  const stats = useMemo(() => {
    let total = 0, seen = 0, overdueCount = 0;
    const count = (list: Topic[]) => list.forEach(t => { if(t.children?.length) count(t.children); else { total++; if(t.seen) seen++; if(isOverdue(t.nextReview)) overdueCount++; } });
    count(subject.topics || []);
    return { total, seen, overdueCount };
  }, [subject]);
  const pct = stats.total === 0 ? 0 : (stats.seen / stats.total) * 100;

  return (
    <div className={`bg-white rounded-lg shadow-sm border mb-4 overflow-hidden ${stats.overdueCount > 0 ? 'border-red-300 ring-1 ring-red-100' : 'border-slate-200'}`}>
      <div className="bg-slate-50 p-4 cursor-pointer flex justify-between items-center hover:bg-slate-100 transition-colors" onClick={() => setIsOpen(!isOpen)}>
        <div className="flex-1 pr-4">
          <div className="flex items-center justify-between">
             <div className="flex items-center gap-2">
                <h3 className="font-bold text-slate-800 text-base md:text-lg">{subject.title}</h3>
                {stats.overdueCount > 0 && (<span className="flex items-center gap-1 text-[10px] bg-red-100 text-red-600 px-2 py-0.5 rounded-full font-bold animate-pulse"><Bell size={10} fill="currentColor"/> {stats.overdueCount} Revisões</span>)}
             </div>
             <div className="flex gap-2">
                <button onClick={(e) => { e.stopPropagation(); onEditTopic(subject.id, subject.title, true); }} className="text-slate-400 hover:text-blue-500 p-1"><Edit2 size={16}/></button>
                <button onClick={(e) => { e.stopPropagation(); onAddTopic(); }} className="text-xs bg-indigo-100 text-indigo-700 px-2 py-1 rounded hover:bg-indigo-200 font-bold flex items-center gap-1"><Plus size={14}/> Tópico</button>
                <button onClick={(e) => { e.stopPropagation(); onDeleteSubject(); }} className="text-slate-400 hover:text-red-500 p-1"><Trash2 size={18}/></button>
             </div>
          </div>
          <div className="mt-2 w-full max-w-xs">
             <div className="flex justify-between text-xs text-slate-500 font-semibold mb-1"><span>Progresso</span><span>{Math.round(pct)}%</span></div>
             <div className="w-full bg-slate-200 rounded-full h-1.5 overflow-hidden"><div className="h-full bg-green-500 transition-all duration-500" style={{ width: `${pct}%` }}></div></div>
          </div>
        </div>
        <div className="text-slate-400 ml-4">{isOpen ? <ChevronUp /> : <ChevronDown />}</div>
      </div>
      {isOpen && <div className="p-3 border-t border-slate-200 bg-slate-50/30">
        {(subject.topics || []).map((topic, idx) => (
            <TopicItem key={topic.id} index={idx} topic={topic} subjectId={subject.id} catId={catId} parentId={null} onReorder={onReorder} onEdit={onEditTopic} {...props} />
        ))}
        {(!subject.topics || subject.topics.length === 0) && <div className="text-center py-4 text-slate-400 italic text-sm">Nenhum tópico cadastrado.</div>}
      </div>}
    </div>
  );
};