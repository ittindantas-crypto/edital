import { GoogleGenAI } from "@google/genai";
import { Edital, Category, Subject, Topic } from "./types";

// Helper to safely get the API Key
const getApiKey = (): string | undefined => {
  return process.env.API_KEY;
};

const ai = new GoogleGenAI({ apiKey: getApiKey() });

export const generateTutorResponse = async (
  topic: string, 
  subject: string, 
  mode: 'explain' | 'quiz' | 'tips'
): Promise<string> => {
  const apiKey = getApiKey();
  if (!apiKey) return "⚠️ API Key não configurada. Configure process.env.API_KEY.";

  let prompt = "";
  if (mode === 'explain') {
    prompt = `Explique de forma didática e resumida (máximo 3 parágrafos) o tópico: "${topic}". Contexto da matéria: ${subject}. Foco em concursos públicos.`;
  } else if (mode === 'quiz') {
    prompt = `Gere uma questão de múltipla escolha (A, B, C, D, E) difícil sobre: "${topic}" (Matéria: ${subject}). Ao final, mostre o gabarito e um breve comentário.`;
  } else if (mode === 'tips') {
    prompt = `Dê 3 dicas práticas e objetivas de como estudar e memorizar o tópico: "${topic}" para provas de alto nível.`;
  }

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        systemInstruction: "Você é um professor especialista em concursos públicos de alto nível."
      }
    });

    return response.text || "Sem resposta da IA.";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "⚠️ Erro ao consultar o Tutor IA. Tente novamente.";
  }
};

// --- OTIMIZAÇÃO DE PERFORMANCE ---
// Injeta IDs e campos de estado no cliente para economizar tokens da IA
const hydrateEditalData = (rawCategories: any[]): Category[] => {
  const generateId = () => Math.random().toString(36).substr(2, 9);

  const hydrateTopic = (t: any): Topic => ({
    id: generateId(),
    text: t.text || "Tópico sem nome",
    seen: false,
    reviews: [],
    children: t.children && Array.isArray(t.children) ? t.children.map(hydrateTopic) : []
  });

  const hydrateSubject = (s: any): Subject => ({
    id: generateId(),
    title: s.title || "Matéria Geral",
    topics: s.topics && Array.isArray(s.topics) ? s.topics.map(hydrateTopic) : []
  });

  const hydrateCategory = (c: any): Category => ({
    id: generateId(),
    title: c.title || "Categoria",
    subjects: c.subjects && Array.isArray(c.subjects) ? c.subjects.map(hydrateSubject) : []
  });

  return rawCategories.map(hydrateCategory);
};

export const parseEditalWithAI = async (text: string, title: string): Promise<Edital> => {
  const apiKey = getApiKey();
  if (!apiKey) throw new Error("API Key ausente.");

  const prompt = `
    ATENÇÃO: Extraia a estrutura do edital abaixo para JSON.
    Objetivo: Ser rápido e preciso.
    
    Estrutura de Saída (JSON minificado):
    {
      "categories": [
        {
          "title": "Nome da Categoria (Ex: Conhecimentos Básicos)",
          "subjects": [
            {
              "title": "Nome da Matéria (Ex: Português)",
              "topics": [
                {
                  "text": "Nome do Tópico",
                  "children": [] // Opcional, se houver subtopicos
                }
              ]
            }
          ]
        }
      ]
    }

    REGRAS CRÍTICAS DE PERFORMANCE:
    1. NÃO gere IDs.
    2. NÃO gere campos "seen" ou "reviews".
    3. NÃO inclua explicações, apenas o JSON.
    4. Agrupe tópicos numerados (1.1, 1.2) em "children" se fizer sentido.
    
    Texto do Edital:
    """
    ${text.substring(0, 45000)}
    """
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        systemInstruction: "You are a JSON extractor. Output only the raw syllabus structure without metadata."
      }
    });

    const resultText = response.text;
    if (!resultText) throw new Error("Resposta vazia da IA.");

    const parsed = JSON.parse(resultText);

    if (!parsed.categories || !Array.isArray(parsed.categories)) {
      throw new Error("A IA não retornou categorias válidas.");
    }

    const hydratedCategories = hydrateEditalData(parsed.categories);

    return {
      id: `ai_${Date.now()}`,
      title,
      createdAt: new Date().toISOString(),
      categories: hydratedCategories
    };

  } catch (error) {
    console.error("AI Parsing Error:", error);
    throw new Error("Falha ao processar edital. Verifique o texto e tente novamente.");
  }
};